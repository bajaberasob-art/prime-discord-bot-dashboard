PRIME Profile Card PNG Templates — 5 varied layouts

Included PNGs are separate overlay assets, not a combined sprite sheet:
- 01_portrait_neon_pink.png: vertical, pink neon profile card
- 02_wide_icy_blue.png: widescreen, icy cyan/blue HUD
- 03_square_violet_crystal.png: square, violet crystal frame
- 04_landscape_emerald.png: landscape, emerald and gold frame
- 05_ultrawide_ruby_gold.png: extra-wide, ruby red and gold frame

The large blank display region and circular avatar opening are transparent where generated as openings; the dark lower panel remains as a readable place for text, XP/progress and stats. The two source renders that had a checkerboard baked into their pixels were cleaned to restore transparency.

These are image assets only. They have not been added to the PRIME GitHub repository or connected to profile renderer metadata yet.
